import unittest

from dash import html

from sembo.content import app
from app import app
import psutil

from sembo.layout.network import update_net_statistic
from sembo.layout.system_components import conversions


class Test(unittest.TestCase):

    def test_update_net_statistic(self):
        net_io_curr = psutil.net_io_counters()
        div = html.Div(
            className="row card-body mt-2 justify-content-center",
            children=[
                html.P(f"Total Bytes Sent: {conversions.get_size(net_io_curr.bytes_sent)}", className="col-3"),
                html.P(f"Total Bytes Received: {conversions.get_size(net_io_curr.bytes_recv)}", className="col-3")
            ]
        )
        #  Content differ due to constant updates
        self.assertNotEqual(update_net_statistic(n=""), div)

