import unittest

from sembo.content import app
from app import app

from sembo.layout.commands import show_command_output, check_image_existance, render_pull_result, remove_loader


class Test(unittest.TestCase):

    def test_remove_loader(self):
        self.assertEqual(remove_loader([]), None)
