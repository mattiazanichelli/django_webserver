import unittest

from sembo.content import app
from app import app

from sembo.layout.commands import show_command_output, check_image_existance, render_pull_result, remove_loader


class Test(unittest.TestCase):

    # def test_show_command_output(self):
    #     pass
    #
    # def test_check_image_existance(self):
    #     pass
    #
    # def test_render_pull_result(self):
    #     pass

    def test_remove_loader(self):
        self.assertEqual(remove_loader([]), None)
