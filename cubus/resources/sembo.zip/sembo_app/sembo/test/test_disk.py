import unittest

import psutil
from dash import html

from sembo.content import app
from app import app
from sembo.layout.system_components import conversions

from sembo.layout.system_components.disk import update_disk_statistic


class Test(unittest.TestCase):

    def test_update_disk_statistic(self):
        disk_io_curr = psutil.disk_io_counters()
        div = html.Div(
            className="row mx-3 card-body mt-2 justify-content-center",
            children=[
                html.P(
                    f"Total read: {conversions.get_size(disk_io_curr.read_bytes)}",
                    id="disk-total-read",
                    className="col-3"
                ),
                html.P(
                    f"Total write: {conversions.get_size(disk_io_curr.write_bytes)}",
                    id="disk-total-read",
                    className="col-3"
                )])
        #  Content differ due to constant updates
        self.assertNotEqual(update_disk_statistic(1), div)
