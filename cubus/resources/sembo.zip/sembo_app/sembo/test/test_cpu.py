import unittest
from time import sleep

import psutil

from sembo.content import app
from app import app
from sembo.layout.system_components.cpu import get_cpu_name, toggle_collapse, update_cpu_freq, update_cpu_perc


class Test(unittest.TestCase):

    def test_get_cpu_name(self):
        current_cpu = "Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz"
        self.assertEqual(get_cpu_name(), current_cpu)

    def test_toggle_collapse(self):
        self.assertFalse(toggle_collapse(1, is_open=True))
        self.assertTrue(toggle_collapse(1, False))

    def test_update_cpu_freq(self):
        #  Different result due to different timing of measurement
        cpufreq = round(psutil.cpu_freq().current / 1000, 2)
        self.assertAlmostEqual(update_cpu_freq(1), cpufreq, delta=0.5)

    def test_update_cpu_perc(self):
        #  Different result due to different timing of measurement
        perc = psutil.cpu_percent(1)
        self.assertAlmostEqual(update_cpu_perc(1), perc, delta=10)
