import unittest

import psutil

from sembo.content import app
from app import app
from sembo.layout.system_components import conversions
from sembo.layout.system_components.ram import update_ram_perc, update_swap_perc, update_ram_bar_values, \
    update_ram_bar_labels, update_swap_bar_values, update_swap_bar_labels


class Test(unittest.TestCase):

    def test_update_ram_perc(self):
        svmem_curr = psutil.virtual_memory()
        self.assertAlmostEqual(update_ram_perc(1), svmem_curr.percent, delta=20)

    def test_update_swap_perc(self):
        swap_curr = psutil.swap_memory().percent
        self.assertAlmostEqual(update_swap_perc(1), swap_curr, delta=20)

    def test_update_ram_bar_values(self):
        svmem_curr = psutil.virtual_memory()
        available = conversions.to_float(conversions.get_size(svmem_curr.available)[:-3])
        used = conversions.to_float(conversions.get_size(svmem_curr.used)[:-3])
        self.assertEqual(update_ram_bar_values(1), (used, available))

    def test_update_ram_bar_labels(self):
        svmem_curr = psutil.virtual_memory()
        used = conversions.get_size(svmem_curr.used)
        available = conversions.get_size(svmem_curr.available)
        self.assertEqual(update_ram_bar_labels(1), (used, available))

    def test_update_swap_bar_values(self):
        swap_curr = psutil.swap_memory()
        used = conversions.to_float(conversions.get_size(swap_curr.used)[:-3])
        free = conversions.to_float(conversions.get_size(swap_curr.free)[:-3])
        self.assertEqual(update_swap_bar_values(1), (used, free))

    def test_update_swap_bar_labels(self):
        swap_curr = psutil.swap_memory()
        used = conversions.get_size(swap_curr.used)
        free = conversions.get_size(swap_curr.free)
        self.assertEqual(update_swap_bar_labels(1), (used, free))
