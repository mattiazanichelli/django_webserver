import unittest

from sembo.layout.system_components import conversions


class Test(unittest.TestCase):

    def test_get_size_1(self):
        free_memory = 512
        total_memory = 1024
        result1 = conversions.get_size(free_memory)
        result2 = conversions.get_size(total_memory)
        self.assertEqual(result1, "512.00 B")
        self.assertEqual(result2, "1.00 KB")

    def test_get_size_2(self):
        memory_kb = 5 * 1024
        result = conversions.get_size(memory_kb)
        self.assertEqual(result, "5.00 KB")

        memory_mb = 5 * 1024 * 1024
        result2 = conversions.get_size(memory_mb)
        self.assertEqual(result2, "5.00 MB")

        memory_gb = 5 * 1024 * 1024 * 1024
        result3 = conversions.get_size(memory_gb)
        self.assertEqual(result3, "5.00 GB")

    def test_get_size_3(self):
        memory1 = 2 * 1024  # 2KB
        memory2 = 2 * 1024 * 1024  # 2MB
        result1 = conversions.get_size(memory1)[:-3]  # Take only the numbers
        result2 = conversions.get_size(memory2)[:-3]
        self.assertTrue(result2 == result1)

        memory3 = 3 * 1024  # 3KB
        memory4 = 2 * 1024 * 1024  # 2MB
        result3 = conversions.get_size(memory3)[:-3]
        result4 = conversions.get_size(memory4)[:-3]
        self.assertTrue(result3 > result4)

    def test_to_float(self):
        var = 5
        self.assertEqual(str(type(var)), "<class 'int'>")
        self.assertEqual(str(type(conversions.to_float(var))), "<class 'float'>")



