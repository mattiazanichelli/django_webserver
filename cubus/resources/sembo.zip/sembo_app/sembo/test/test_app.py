import unittest

from sembo.content import app
from app import get_output_from_command, get_ip_addr


class Test(unittest.TestCase):

    def test_get_output_from_command(self):
        option = "-i"
        stdout, stderr = get_output_from_command(option)
        self.assertEqual(stderr, "")
        self.assertEqual(stdout, "127.0.1.1\n")

    def test_get_ip_addr(self):
        address = get_ip_addr()
        self.assertEqual(address, "127.0.1.1")

