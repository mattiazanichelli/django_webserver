import unittest

from sembo.content import app, render_content, build_home_tab, build_system_tab, build_network_tab, build_commands_tab


class Test(unittest.TestCase):

    def test_render_content(self):
        tab1 = "home-tab"
        self.assertEqual(str(render_content(tab1)), str(build_home_tab()))

        # Difference in actual components status
        self.maxDiff = None
        tab2 = 'system-tab'
        self.assertNotEqual(str(render_content(tab2)), str(build_system_tab()))

        tab3 = 'network-tab'
        self.assertEqual(str(render_content(tab3)), str(build_network_tab()))

        tab4 = 'commands-tab'
        self.assertEqual(str(render_content(tab4)), str(build_commands_tab()))
