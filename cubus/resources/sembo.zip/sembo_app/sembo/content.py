import dash_bootstrap_components as dbc
from dash import html
from dash.dependencies import Input, Output

from sembo.index import app
from sembo.layout import home, system, network, commands


def build_banner():
    return dbc.CardHeader(
        id="banner",
        className="banner border-secondary",
        children=[
            html.Div(
                id="banner-text",
                className="text-center mt-3",
                children=[
                    html.H2("SeMBo"),
                    html.H3("Server Monitoring Dashboard"),
                ],
            ),
        ],
    )


def build_tabs():
    return dbc.Tabs(
        id="app-tabs",
        className="bg-dark text-light nav nav-tabs nav-fill",
        style={
            "border": "#FF7F0E"
        },

        children=[
            dbc.Tab(
                id="home",
                label="Home",
                tab_id="home-tab",
                style={
                    "fontSize": "20px",
                },
                labelClassName="text-light",
                label_style={
                    "backgroundColor": "#212529",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                active_label_style={
                    "border": "2px solid #FFFFFF",
                    "backgroundColor": "#212529",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                activeLabelClassName="text-light",
                activeTabClassName="fw-bold",
            ),
            dbc.Tab(
                id="system",
                label="System",
                tab_id="system-tab",
                style={
                    "fontSize": "20px",
                },
                label_style={
                    "backgroundColor": "#212529",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                labelClassName="text-light",
                active_label_style={
                    "backgroundColor": "#212529",
                    "border": "2px solid #FFFFFF",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                activeLabelClassName="text-light",
                activeTabClassName="fw-bold",
            ),
            dbc.Tab(
                id="network",
                label="Network",
                tab_id="network-tab",
                style={
                    "fontSize": "20px",
                },
                label_style={
                    "backgroundColor": "#212529",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                labelClassName="text-light",
                active_label_style={
                    "backgroundColor": "#212529",
                    "border": "2px solid #FFFFFF",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                activeLabelClassName="text-light",
                activeTabClassName="fw-bold",
            ),
            dbc.Tab(
                id="commands",
                label="Commands",
                tab_id="commands-tab",
                style={
                    "fontSize": "20px",
                },
                label_style={
                    "backgroundColor": "#212529",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                labelClassName="text-light",
                active_label_style={
                    "backgroundColor": "#212529",
                    "border": "2px solid #FFFFFF",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                activeLabelClassName="text-light",
                activeTabClassName="fw-bold",
            ),
        ],
    )


def build_home_tab():
    return home.create_home_tab()


def build_network_tab():
    return network.create_network_tab()


def build_system_tab():
    return system.create_system_tab()


def build_commands_tab():
    return commands.create_commands_tab()


app.layout = dbc.Card(
    id="big-app-container",
    className="bg-dark text-light",
    children=[
        build_banner(),
        dbc.CardBody(
            id="app-container",
            children=[
                build_tabs(),
                html.Div(id="tabs-content"),
            ],
        ),
    ],
)


@app.callback(Output('tabs-content', 'children'), Input('app-tabs', 'active_tab'))
def render_content(tab):
    if tab == 'home-tab':
        return build_home_tab()
    elif tab == 'system-tab':
        return build_system_tab()
    elif tab == 'network-tab':
        return build_network_tab()
    elif tab == 'commands-tab':
        return build_commands_tab()
