import subprocess

import dash
import dash_bootstrap_components as dbc
from dash import html, Input, Output

from app import app


# def get_output_from_command(command):
#     process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True,
#                                universal_newlines=True)
#     out = process.stdout.readlines()
#     err = process.stderr.readlines()
#     return out, err


def create_info_card():
    return html.Div(
        id="info-card",
        className="card border-secondary bg-dark text-light text-center mb-3",
        children=[
            html.H5("INFO", className="card-header border-secondary"),
            html.Div(
                id="info-card-body",
                className="card-body",
                style={"fontSize": "20px"},
                children=[
                    html.P("In this tab, you can execute commands and get the output as a result."),
                    html.P("The list of buttons below allows you to execute specific commands "
                           "that are passed directly to the terminal."),
                    html.P("Among the possibilities you can:"),
                    html.Ul(
                        className="text-start",
                        style={"paddingLeft": "40%", },
                        children=[
                            html.Li("List docker images and containers present in the system"),
                            html.Li("Add one or more docker images."),
                            html.Li("Check the network status with the netstat command "
                                    "(\"netstat -l\" command is executed)"),
                            html.Li("List the active processes (\"ps -a\" command is executed)"),
                            html.Li("Execute the command \"apr -e -v\""),
                            html.Li("Get the list of groups present in the system (\"groups\" command is executed)"),
                        ],
                    ),
                    html.P(
                        "For security reasons, it has been chosen not to execute commands that require sudo privileges")
                ]
            ),
        ]
    )


# def create_input_card():
#     return html.Div(
#         id="input-card",
#         className="card border-secondary bg-dark text-light mb-3 mt-3",
#         style={
#             "marginLeft": "10px",
#             "marginRight": "10px",
#         },
#         children=[
#             html.H5("INPUT", className="card-header border-secondary text-center"),
#             html.Div(
#                 id="input-card-body",
#                 className="card-body",
#                 children=[
#                     dbc.FormText(
#                         "You can press <tab> to highligt the submit button and then press Enter",
#                         id="input-tip",
#                         style={
#                             "fontSize": "14px",
#                         },
#                     ),
#                     dbc.Textarea(
#                         id="terminal-input",
#                         className="mb-3 mt-3 bg-dark text-light border-primary",
#                         placeholder=">> Input",
#                         size="lg",
#                         style={
#                             "width": "100%",
#                             "height": 300,
#                         },
#                     ),
#                     dbc.Button(
#                         "Submit",
#                         id="submit-button",
#                         className="mt-3 mb-3",
#                         style={"height": "45px", "width": "100px"},
#                         color="dark border-primary",
#                         n_clicks=0,
#                     ),
#                 ]
#             ),
#         ]
#     )


def create_output_card():
    return html.Div(
        id="output-card",
        className="card border-secondary bg-dark text-light mb-3 mt-3 align-items-stretch",
        children=[
            html.H5("OUTPUT", className="card-header border-secondary text-center"),
            html.Div(
                id="output-card-body",
                className="card-body",
                children=[
                    html.Div(
                        id="clear-output",
                        style={
                            "fontSize": "20px",
                        },
                    ),
                ]
            ),
        ]
    )


def create_commands_card():
    return html.Div(
        id="commands-card",
        className="card border-secondary bg-dark text-light mb-3 mt-3 col",
        children=[
            html.H5("COMMANDS", className="card-header border-secondary text-center"),
            html.Div(
                id="commands-card-body",
                className="card-body text-center",
                children=[
                    dbc.Button(
                        "Docker images & containers",
                        id="docker-images&containers-button",
                        color="dark",
                        size="lg",
                        className="border-primary mx-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "Add Docker image",
                        id="docker-pull-image-button",
                        color="dark",
                        size="lg",
                        className="border-primary me-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "Netstat",
                        id="netstat-button",
                        color="dark",
                        size="lg",
                        className="border-primary me-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "Processes",
                        id="ps-button",
                        color="dark",
                        size="lg",
                        className="border-primary me-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "Arp",
                        id="arp-button",
                        color="dark",
                        size="lg",
                        className="border-primary me-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "List groups",
                        id="list-groups-button",
                        color="dark",
                        size="lg",
                        className="border-primary me-5 ",
                        n_clicks=0,
                    ),
                    dbc.Button(
                        "Clear",
                        id="clear-output-button",
                        color="dark",
                        size="lg",
                        className="border-danger",
                        n_clicks=0,
                    ),
                ]
            ),
        ]
    )


def create_terminal_card():
    return html.Div(
        id="terminal-card",
        className="card-deck",
        children=[
            html.Div(
                id="io-container",
                className="card border-secondary bg-dark text-light mb-3",
                children=[
                    html.H5("TERMINAL", className="card-header border-secondary text-center"),
                    html.Div(
                        id="io-body",
                        className="card-body",
                        children=[
                            # create_input_card(),
                            create_commands_card(),
                            create_output_card(),
                        ]
                    ),
                ]
            ),
        ]
    )


def create_commands_tab():
    return html.Div(
        className="mt-3 mx-5",
        children=[
            create_info_card(),
            create_terminal_card()
        ]
    )


def create_docker_image_form():
    return html.Div(
        id="docker-image-form",
        className="",
        children=[
            dbc.Label("Insert Docker image(s)"),
            dbc.Input(
                id="docker-image-name",
                size="lg",
                placeholder="e.g. alpine, mongo, mongo-express",
                type="text",
                className="bg-dark text-light mb-3",
                style={"width": "50%"},
            ),
            dbc.Button("Pull", size="lg", id="docker-pull-button", n_clicks=0, color="dark",
                       className="border-primary me-1"),
            html.P(),  # Just for spacing
            html.P("You can insert multiple images, be sure to separate them with commas."),
            html.Span("Make sure the images names are correct, refer to the "),
            html.A("Docker Hub", href="https://hub.docker.com/search?q=&operating_system=linux", target="_blank"),
            html.Span(" for information about images names."),
            html.P("Note: only official docker images are verified and accepted as input."),
            html.P(id="docker-images-output", className=""),  # Adding pulling information here (loading, etc.)
            html.P(id="docker-pull-result", className=""),  # Adding output of pulled images here
            html.Div(id="pulling-result-message", className="text-success")
        ]
    )


def check_docker_image_existance(image):
    process = subprocess.Popen(f"docker search --filter is-official=true --limit 1 {image}",
                               stdout=subprocess.PIPE, shell=True, universal_newlines=True)
    out = process.stdout.readlines()[1]  # Get second line of output, the line containing the image name
    image = out.replace("'", "").split("  ")[0]
    return image


@app.callback(Output('output-card-body', 'children'),
              Input('docker-images&containers-button', 'n_clicks'),
              Input('docker-pull-image-button', 'n_clicks'),
              Input('netstat-button', 'n_clicks'),
              Input('ps-button', 'n_clicks'),
              Input('arp-button', 'n_clicks'),
              Input('list-groups-button', 'n_clicks'),
              Input('clear-output-button', 'n_clicks'))
def show_netstat_output(ua1, ua2, ua3, ua4, ua5, ua6, ua7):  # --> ua = useless argument
    ctx = dash.callback_context
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
    children_list = []

    if trigger_id == "docker-images&containers-button":
        process = subprocess.Popen(
            "echo \"Docker Images:\" && docker images && echo \"Docker Containers:\" && docker ps",
            stdout=subprocess.PIPE,
            shell=True,
            universal_newlines=True)
        out = process.stdout.readlines()
        for line in out:
            children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
        return children_list
    elif trigger_id == "docker-pull-image-button":
        children_list.append(create_docker_image_form())
        return children_list
    elif trigger_id == "netstat-button":
        process = subprocess.Popen(
            ['netstat', '-l'],
            stdout=subprocess.PIPE,
            shell=True,
            universal_newlines=True)
        out = process.stdout.readlines()
        for line in out:
            children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
        return children_list
    elif trigger_id == "ps-button":
        process = subprocess.Popen(
            ['ps', '-A'],
            stdout=subprocess.PIPE,
            shell=True,
            universal_newlines=True)
        out = process.stdout.readlines()
        for line in out:
            children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
        return children_list
    elif trigger_id == "arp-button":
        process = subprocess.Popen(
            ['arp', '-e', '-v'],
            stdout=subprocess.PIPE,
            shell=True,
            universal_newlines=True)
        out = process.stdout.readlines()
        for line in out:
            children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
        return children_list
    elif trigger_id == "list-groups-button":
        process = subprocess.Popen(
            "groups",
            stdout=subprocess.PIPE,
            shell=True,
            universal_newlines=True)
        out = process.stdout.readlines()
        for line in out:
            children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
        return children_list
    elif trigger_id == "clear-output-button":
        return ""
    else:
        return "The output will be shown here"


@app.callback(Output('docker-images-output', 'children'),
              Input('docker-image-name', 'value'),
              Input('docker-pull-button', 'n_clicks'))
def check_image_existance(docker_input, n_clicks):
    if n_clicks > 0:
        docker_images = str(docker_input).split(", ")
        checked_images = []
        for image in docker_images:
            checked_images.append(check_docker_image_existance(image))
        # return f"images checked {checked_images}"
        return html.P(
            "Pulling images...",
            id="docker-pulling-message",
        ), html.P(
            f"{checked_images}",
            id="docker-images-list",
            style={"display": "none"},
        ), html.Div(
            className="spinner-border text-primary",
            id="pulling-images-loader",
            style={"display": ""},
            role="status"
        )


@app.callback(Output('docker-pull-result', 'children'),
              Input('docker-pull-button', 'n_clicks'),
              Input('docker-images-output', 'children'))
def render_pull_result(n_clicks, children):
    if n_clicks > 0:
        images = str(children[1]['props']['children']).replace("'", "").replace("[", "").replace("]", "").split(", ")
        children_list = []
        for image in images:
            process = subprocess.Popen(
                f"docker pull {image}",
                stdout=subprocess.PIPE,
                shell=True,
                universal_newlines=True)
            out = process.stdout.readlines()
            for line in out:
                children_list.append(html.Pre(line, style={"margin": 0, "fontSize": "18px"}))
            children_list.append(html.P(id="space-between-images"))  # Just for spacing
        children_list.append(html.P("Done!", className="text-success mt-3", style={"fontSize": "18px"}))
        return children_list


@app.callback(Output('pulling-images-loader', 'style'),
              Input('docker-pull-result', 'children'))
def remove_loader(children):
    if len(children) > 0:
        return {'display': 'none'}

