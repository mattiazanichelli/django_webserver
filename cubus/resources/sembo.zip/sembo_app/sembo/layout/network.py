import psutil
import uuid
from dash import dcc, html, Input, Output

from app import app
from sembo.layout.system_components import conversions


def create_network_card():
    # get all network interfaces (virtual and physical)
    if_addrs = psutil.net_if_addrs()

    container_children = []

    for interface_name, interface_addresses in if_addrs.items():
        for address in interface_addresses:
            interface_address = str(address.address).upper()
            interface_network = str(address.netmask).upper()
            interface_broadcast = str(address.broadcast).upper()
            mac_address = str(hex(uuid.getnode())).upper()
            if str(address.family) == 'AddressFamily.AF_INET':
                container_children.append(html.Div(
                    id=f"{interface_name}-card",
                    className="card col mx-3 border-secondary bg-dark text-light mb-4 text-center",
                    children=[
                        html.H5(f"Interface: {interface_name}", className="card-header border-secondary"),
                        html.Div(
                            className="card-body align-items-center",
                            children=[
                                html.Div(
                                    id="family-inet",
                                    className="text-center",
                                    children=[
                                        html.P(f"  IP Address: {interface_address}", className=""),
                                        html.P(f"  Netmask: {interface_network}", className=""),
                                        html.P(f"  Broadcast IP: {interface_broadcast}", className=""),
                                        html.P(f"  MAC Address: {mac_address}", className=""),
                                    ]
                                ),
                            ]
                        ),
                    ]
                ))
    # get IO statistics since boot
    container_children.append(html.Div(
        id="net-statistics",
        className="card mx-5 border-secondary bg-dark text-light text-center",
        style={
            "fontSize": "18px",
            "fontWeight": "bold",
        },
        children=[
            html.H5("Network statistics since boot", className="card-header border-secondary"),
            html.Div(
                id="net-read&write",
                # Here goes update_net_statistic() results
            ),
            dcc.Interval(
                id="net-statistics-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
        ]
    ))

    return html.Div(
        id="network-info-container",
        className="card-deck row justify-content-center",
        children=container_children,
    )


def create_network_tab():
    return html.Div(
        className="mt-3 card-deck row justify-content-center mx-5",
        children=[
            html.Div(
                id="network-info-container",
                className="col mt-3",
                children=[
                    html.Div(
                        id="network-stats",
                        className="card border-secondary bg-dark text-light mt-3",
                        children=[
                            html.H4("INTERFACES", className='card-header border-secondary text-center'),
                            html.Div(
                                className="card-body row justify-content-center",
                                children=[
                                    create_network_card(),
                                ]
                            )
                        ]
                    )
                ]
            )
        ]
    )


@app.callback(Output('net-read&write', 'children'),
              Input('net-statistics-interval', 'n_intervals'))
def update_net_statistic(n):
    net_io_curr = psutil.net_io_counters()
    return html.Div(
        className="row card-body mt-2 justify-content-center",
        children=[
            html.P(f"Total Bytes Sent: {conversions.get_size(net_io_curr.bytes_sent)}", className="col-3"),
            html.P(f"Total Bytes Received: {conversions.get_size(net_io_curr.bytes_recv)}", className="col-3")
        ]
    )
