import platform

from dash import html

from ..layout.system_components.cpu import get_cpu_name

uname = platform.uname()


def create_home_tab():
    return html.Div(
        className="mt-3 bg-dark text-light align-items-stretch text-center",
        children=[
            html.H1(
                "Welcome to SeMBo!",
                style={
                    'paddingTop': '50px',
                    'textDecoration': 'underline',
                    'fontWeight': 'bold',
                }
            ),
            html.H2(
                "The Server Monitor Dashboard for your custom Ubuntu server",
                style={
                    'paddingTop': '20px',
                }
            ),
            html.Hr(
                className="border-2 border-top",
                style={"marginLeft": "25%", "marginRight": "25%"},
            ),
            html.Br(),
            html.Div(
                id="outer-info-container",
                className="col text-center align-items-end",
                style={"paddingTop": "1rem"},
                children=[
                    html.Div(
                        id="tabs-info-container",
                        className="row",
                        style={"paddingBottom": "2rem"},
                        children=[
                            html.H3("Tabs"),
                            html.Div(
                                style={'paddingTop': '10px', "fontSize": "20px"},
                                children=[
                                    html.P("This is the Home tab"),
                                    html.P("Under the System tab you can monitor the CPU, RAM and disk status"),
                                    html.P("Under the Network tab you can get a summary of the system interfaces"),
                                    html.P("Under the Commands tab you can execute some commands"),
                                ]
                            ),
                        ]
                    ),
                    html.Hr(
                        className="mb-3 border-2 border-top",
                        style={"marginLeft": "35%", "marginRight": "35%"},
                    ),
                    html.Div(
                        id="server-info-container",
                        className="row",
                        style={"paddingTop": "2rem"},
                        children=[
                            html.H3("Server Information", style={
                                'textAlign': 'center',
                            }),
                            html.Div(
                                className="container",
                                style={'paddingTop': '10px', "fontSize": "20px"},
                                children=[
                                    html.P(f"System: {uname.system}"),
                                    html.P(f"Node Name: {uname.node}"),
                                    html.P(f"Release: {uname.release}"),
                                    html.P(f"Version: {uname.version}"),
                                    html.P(f"Machine: {uname.machine}"),
                                    html.P(f"Processor: {get_cpu_name()}"),
                                ])
                        ]
                    ),
                ]
            ),
        ])
