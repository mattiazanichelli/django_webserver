from dash import html

from ..layout.system_components import disk, cpu, ram


def create_system_tab():
    return html.Div(
        className="mt-3 card-deck row",
        style={
            "marginLeft": "1rem",
        },
        children=[
            html.Div(
                id="cpu&ram-container",
                className="row mt-3 align-items-start justify-content-center",
                children=[
                    html.Div(
                        id="cpu-stats",
                        className="card mx-3 col border-secondary bg-dark text-light",
                        children=[
                            html.H4("CPU", className="card-header border-secondary text-center"),
                            cpu.create_cpu_card(),
                        ],
                    ),
                    html.Div(
                        id="ram-stats",
                        className="card mx-3 col border-secondary bg-dark text-light",
                        children=[
                            html.H4("RAM", className="card-header border-secondary text-center"),
                            ram.create_ram_card(),
                        ],
                    ),
                ]
            ),
            html.Div(
                id="disk-container",
                className="row mt-3",
                children=[
                    html.Div(
                        id="disk-stats",
                        className="card mx-3 col border-secondary bg-dark text-light",
                        children=[
                            html.H4("DISK", className="card-header border-secondary text-center"),
                            html.Div(
                                className="card-body bd-dark text-light",
                                children=[
                                    disk.create_disk_card(),
                                ]
                            ),

                        ],
                    ),
                ]
            ),
        ])

