import dash_bootstrap_components as dbc
import dash_daq
import psutil
from dash import dcc, html, Input, Output

from app import app
from ..system_components import conversions

svmem = psutil.virtual_memory()
swap = psutil.swap_memory()


def create_ram_info():
    return html.Div(
        id="ram-info",
        className="container mb-3 text-center",
        children=[
            html.P("Memory size"),
            html.Div(
                className="row justify-content-center",
                children=[
                    html.P(f"Total RAM: {conversions.get_size(svmem.total)}", className="col-3"),
                    html.P(f"Total SWAP: {conversions.get_size(swap.total)}", className="col-3"),
                ]
            ),
            html.Hr(
                className="border-2 border-top mb-4 col",
                style={"marginLeft": "30%", "marginRight": "30%"},
            ),
        ]
    )


def create_ram_perc():
    return html.Div(
        id="ram-usage",
        className="text-center col",
        style={"height": "318px"},
        children=[
            html.P("RAM Usage %"),
            dcc.Interval(
                id="ram-perc-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
            dash_daq.Gauge(
                color={
                    "gradient": True,
                    "ranges": {
                        "#1F77B4": [0, 50],
                        "#FFC200": [50, 80],
                        "#FF7F0E": [80, 100],
                    },
                },
                id="ram-perc",
                units="%",
                size=250,
                max=100,
                min=0,
                value=svmem.percent,
                showCurrentValue=True,
            ),
        ],
    )


def create_memory_bar(name):
    memory_type = ""
    total, used, free = 0.0, 0.0, 0.0
    if name == 'RAM':
        memory_type = svmem
        free = conversions.to_float((conversions.get_size(memory_type.available)[:-3]))
    elif name == 'SWAP':
        memory_type = swap
        free = conversions.to_float((conversions.get_size(memory_type.free)[:-3]))

    total = conversions.to_float(conversions.get_size(memory_type.total)[:-3])
    used = conversions.to_float(conversions.get_size(memory_type.used)[:-3])

    # Case when used is in MB and free is in GB
    if used > free:
        used /= 1024

    return html.Div(
        id=f"{name}-bar",
        className="text-center",
        style={
            "paddingLeft": "20%",
            "paddingRight": "20%",
            "paddingBottom": "10px",
        },
        children=[
            html.P(
                f"{name} Usage",
                className="mt-3 mb-3",
                style={"paddingBottom": "10px"}
            ),
            dcc.Interval(
                id=f"{name}-bar-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
            dbc.Progress(
                [
                    dbc.Progress(
                        id=f"{name}-bar-used",
                        value=used,
                        label=f"{used} GB",
                        color="#FF7F0E",
                        bar=True,
                        style={"height": "30px"},
                        className="mb-3 text-dark",
                        max=free,
                    ),
                    dbc.Progress(
                        id=f"{name}-bar-free",
                        value=free,
                        label=f"{free} GB",
                        color="#1F77B4",
                        bar=True,
                        style={"height": "30px"},
                        className="mb-3",
                        max=free,
                    )
                ],
                style={
                    "height": "30px",
                    "fontSize": "16px",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                id=f"{name}-bar-total",
                className="mb-3",
                max=total,
            )
        ]
    )


def create_ram_bar():
    return create_memory_bar("RAM")


def create_swap_perc():
    return html.Div(
        id="swap-usage",
        className="text-center col",
        style={"height": "318px"},
        children=[
            html.P("SWAP Usage %"),
            dcc.Interval(
                id="swap-perc-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
            dash_daq.Gauge(
                color={
                    "gradient": True,
                    "ranges": {
                        "#1F77B4": [0, 50],
                        "#FFC200": [50, 80],
                        "#FF7F0E": [80, 100],
                    },
                },
                id="swap-perc",
                units="%",
                size=250,
                max=100,
                min=0,
                value=swap.percent,
                showCurrentValue=True,
            ),
        ],
    )


def create_swap_bar():
    return create_memory_bar("SWAP")


def create_ram_container():
    return html.Div(
        id="ram-container",
        className="col",
        children=[
            create_ram_perc(),
            create_ram_bar(),
        ]
    )


def create_swap_container():
    return html.Div(
        id="swap-container",
        className="col",
        children=[
            create_swap_perc(),
            create_swap_bar(),
        ]
    )


def create_ram_card():
    return html.Div(
        id="ram-card",
        className="mt-3 card-body row align-items-center",
        children=[
            create_ram_info(),
            html.Div(
                id="ram-cards",
                className="container row",
                children=[
                    create_ram_container(),
                    create_swap_container(),
                ]
            ),
        ]
    )


# CALLBACKS
@app.callback(Output('ram-perc', 'value'),
              Input('ram-perc-interval', 'n_intervals'))
def update_ram_perc(n):
    svmem_curr = psutil.virtual_memory()
    return svmem_curr.percent


@app.callback(Output('swap-perc', 'value'),
              Input('swap-perc-interval', 'n_intervals'))
def update_swap_perc(n):
    swap_curr = psutil.swap_memory()
    return swap_curr.percent


@app.callback(Output('RAM-bar-used', 'value'),
              Output('RAM-bar-free', 'value'),
              Input('RAM-bar-interval', 'n_intervals'))
def update_ram_bar_values(n):
    svmem_curr = psutil.virtual_memory()
    used = conversions.to_float(conversions.get_size(svmem_curr.used)[:-3])
    available = conversions.to_float(conversions.get_size(svmem_curr.available)[:-3])
    if used > available:
        used /= 1024
    return used, available


@app.callback(Output('RAM-bar-used', 'label'),
              Output('RAM-bar-free', 'label'),
              Input('RAM-bar-interval', 'n_intervals'))
def update_ram_bar_labels(n):
    svmem_curr = psutil.virtual_memory()
    used = conversions.get_size(svmem_curr.used)
    available = conversions.get_size(svmem_curr.available)
    return used, available


@app.callback(Output('SWAP-bar-used', 'value'),
              Output('SWAP-bar-free', 'value'),
              Input('SWAP-bar-interval', 'n_intervals'))
def update_swap_bar_values(n):
    swap_curr = psutil.swap_memory()
    used = conversions.to_float(conversions.get_size(swap_curr.used)[:-3])
    free = conversions.to_float(conversions.get_size(swap_curr.free)[:-3])
    if used > free:
        used /= 1024
    return used, free


@app.callback(Output('SWAP-bar-used', 'label'),
              Output('SWAP-bar-free', 'label'),
              Input('SWAP-bar-interval', 'n_intervals'))
def update_swap_bar_labels(n):
    swap_curr = psutil.swap_memory()
    used = conversions.get_size(swap_curr.used)
    free = conversions.get_size(swap_curr.free)
    return used, free
