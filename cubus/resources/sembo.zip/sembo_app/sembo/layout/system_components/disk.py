import dash_bootstrap_components as dbc
import psutil
from dash import dcc, html, Input, Output

from app import app
from ..system_components import conversions


def create_partition_info(partition):
    partition_div = html.Div(
        className="card col border-secondary bg-dark text-light text-center mb-3",
        style={
            "fontSize": "18px",
            "marginLeft": "8px",
            "marginRight": "8px",
        },
    )
    children = [
        html.H5(f"Device: {partition.device}", className="card-header border-secondary"),
        html.Div(
            className="row justify-content-center",
            children=[
                html.P(f"Mountpoint: {partition.mountpoint}", className="col-3 mt-5"),
                html.P(f"File system type: {partition.fstype}", className="col-3 mt-5")
            ]
        ),
        html.Hr(
            className="border-2 border-top mb-5 col",
            style={"marginLeft": "30%", "marginRight": "30%"},
        ),
    ]

    try:
        partition_usage = psutil.disk_usage(partition.mountpoint)
    except PermissionError:
        # This can be catched due to the disk that isn't ready
        partition_div.children = children
        return partition_div

    total = conversions.get_size(partition_usage.total)
    used = conversions.get_size(partition_usage.used)
    free = conversions.get_size(partition_usage.free)
    percent = conversions.get_size(partition_usage.percent)

    children.append(html.P(f"Total Size: {total}", style={"paddingBottom": "20px"}))
    children.append(html.Div(
        id=f"{partition.device}-charts",
        className="col",
        children=[
            create_disk_bar(used[:-2], free[:-2], used[-2:], free[-2:]),
            create_disk_pie_chart(partition.device, percent[:-2])
        ],
    ))

    partition_div.children = children

    return partition_div


def create_disk_pie_chart(name, percentage):
    return html.Div(
        id=f"{name}-pie-chart-container",
        className="text-center mt-4",
        children=[
            dcc.Graph(
                id=f"{name}-pie-chart",
                figure={
                    "data": [
                        {
                            "labels": ['Used', 'Free'],
                            "values": [percentage, 100 - float(percentage)],
                            "type": "pie",
                            "rotation": 45,
                            "marker": {
                                "colors": {
                                    "Used": "blue",
                                    "Free": "Green",
                                },
                                "line": {
                                    "color": "#212529", "width": 1
                                }
                            },
                            "hoverinfo": "label",
                            "textinfo": "values",
                            "textfont": {
                                "size": "18",
                            },
                        },
                    ],
                    "layout": {
                        "margin": dict(l=50, r=50, t=50, b=50),
                        "height": 350,
                        "title": {
                            "text": "Disk Usage %",
                            "font": {
                                "color": "white",
                                "size": "20",
                            },
                            "xanchor": "auto",
                            "pad": {
                                "b": 20,
                                "l": 0,
                                "r": 0,
                                "t": 20,
                            },
                        },
                        "showlegend": True,
                        "paper_bgcolor": "rgba(0,0,0,0)",
                        "font": {
                            "color": "white",
                            "size": "20",
                        },
                        "autosize": True,
                        "legend": {
                            "traceorder": "reversed",
                            "font": {
                                "size": "20",
                            },
                            "x": "0.1",
                            "y": "1",
                        },
                    },
                },
            )
        ]
    )


def create_disk_bar(used, free, used_unit, free_unit):
    if used_unit == 'KB' and free_unit == 'MB':
        used = conversions.to_float(used)
        used /= 1024

    return html.Div(
        # id="",
        style={
            "paddingLeft": "20%",
            "paddingRight": "20%",
            "paddingBottom": "10px",
        },
        children=[
            dbc.Progress(
                [
                    dbc.Progress(
                        value=used,
                        label=f"{used}{used_unit}",
                        color="#FF7F0E",
                        bar=True,
                        style={"height": "35px"},
                        className="mb-3 text-dark",
                        max=free,
                    ),
                    dbc.Progress(
                        value=free,
                        label=f"{free}{free_unit}",
                        color="#1F77B4",
                        bar=True,
                        style={"height": "35px"},
                        className="mb-3",
                        max=free,
                    )
                ],
                style={
                    "height": "35px",
                    "fontSize": "18px",
                    "borderTopLeftRadius": "20px",
                    "borderTopRightRadius": "20px",
                    "borderBottomLeftRadius": "20px",
                    "borderBottomRightRadius": "20px",
                },
                className="mb-3",
                max=free,
            )
        ]
    )


def create_disk_card():
    partitions = psutil.disk_partitions()

    container_children = []
    for partition in partitions:
        if "snap" in partition.mountpoint:
            continue
        container_children.append(create_partition_info(partition))

    container_children.append(html.Div(
        id="io-statistics",
        className="card  justify-content-center border-secondary bg-dark text-light text-center",
        style={
            "fontSize": "18px",
            "fontWeight": "bold",
        },
        children=[
            html.H5("IO statistics since boot", className="card-header border-secondary"),
            html.Div(
                id="disk-read&write",
                children=[
                    # Here goes update_disk_statistic() results
                ]
            ),
            dcc.Interval(
                id="disk-statistics-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
        ]
    ))

    return html.Div(
        id="disk-info-container",
        className="card-deck row justify-content-center align-items-start",
        children=container_children,
    )


@app.callback(Output('disk-read&write', 'children'),
              Input('disk-statistics-interval', 'n_intervals'))
def update_disk_statistic(n):
    disk_io_curr = psutil.disk_io_counters()
    return html.Div(
        className="row mx-3 card-body mt-2 justify-content-center",
        children=[
            html.P(
                f"Total read: {conversions.get_size(disk_io_curr.read_bytes)}",
                id="disk-total-read",
                className="col-3"
            ),
            html.P(
                f"Total write: {conversions.get_size(disk_io_curr.write_bytes)}",
                id="disk-total-read",
                className="col-3"
            )])
