def get_size(nrbytes, suffix="B"):
    """
    Scale bytes to its proper format
    e.g:
        1253656 => '1.20MB'
        1253656678 => '1.17GB'
    """
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if nrbytes < factor:
            return f"{nrbytes:.2f} {unit}{suffix}"
        nrbytes /= factor


def to_float(value):
    return float(value)
