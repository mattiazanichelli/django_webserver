import dash_bootstrap_components as dbc
import dash_daq
import math

import psutil
import subprocess
from dash import dcc, html, Input, Output, State
from app import app


def get_cpu_name():
    command = "cat /proc/cpuinfo | grep 'CPU' | uniq"
    cpu_name = subprocess.check_output(command, shell=True).decode().split('\t')
    cpu_name = cpu_name[1].replace(": ", "").replace("\n", "")
    return cpu_name


def create_cpu_freq():
    cpufreq = psutil.cpu_freq()
    min_freq = round(cpufreq.min / 1000, 2)
    max_freq = round(cpufreq.max / 1000, 2)
    current_freq = round(cpufreq.current / 1000, 2)

    # In case max CPU is not available
    if max_freq == 0:
        cpu_name = get_cpu_name()
        if "Intel(R)" in cpu_name:
            cpu_name = cpu_name.split(" ")[-1]
            max_freq = float(cpu_name[:-3])

    return html.Div(
        id="cpu-usage-freq",
        className="text-center col",
        style={"height": "300px"},
        children=[
            html.P("CPU Freq. (Ghz)"),
            dcc.Interval(
                id="cpu-freq-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
            dash_daq.Gauge(
                color={
                    "gradient": True,
                    "ranges": {
                        "#1F77B4": [0, 2.0],
                        "#FFC200": [2.0, 3.0],
                        "#FF7F0E": [3.0, math.ceil(max_freq)],
                    },
                },
                id="cpu-freq",
                size=250,
                units="Ghz",
                max=math.ceil(max_freq),
                min=0,
                value=current_freq,
                scale={
                    'start': 0,
                    'interval': 0.5,
                    'labelInterval': 1
                },
                showCurrentValue=True,
            ),
        ],
    )


def create_cpu_perc():
    return html.Div(
        id="cpu-usage-perc",
        className="text-center col",
        style={"height": "300px"},
        children=[
            html.P("CPU Usage (%)"),
            dcc.Interval(
                id="cpu-perc-interval",
                interval=5 * 1000,
                n_intervals=0
            ),
            dash_daq.Gauge(
                color={
                    "gradient": True,
                    "ranges": {
                        "#1F77B4": [0, 50],
                        "#FFC200": [50, 80],
                        "#FF7F0E": [80, 100],
                    },
                },
                id="cpu-perc",
                size=250,
                units="%",
                max=100,
                min=0,
                value=psutil.cpu_percent(),
                showCurrentValue=True,
            ),
        ],
    )


def create_cores_perc():
    # Core usage
    core_list = []

    for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=1)):
        core_list.append(
            html.Tr([html.Td(f"Core {i}"), html.Td(f"{percentage}")])
        )

    table_header = [
        html.Thead(html.Tr([html.Th("Core #"), html.Th("Usage %")]))
    ]
    table_body = [html.Tbody(core_list)]

    return html.Div(
        id="cores-list",
        className="",
        children=[
            html.Div(
                id="collapse-cores-table",
                className="text-center",
                children=[
                    dbc.Button(
                        "CPU Usage per core",
                        id="collapse-button",
                        className="mt-4 mb-3",
                        style={"height": "45px"},
                        color="dark border-secondary",
                        n_clicks=0,
                    ),
                    dbc.Collapse(
                        dbc.Card(
                            className="bg-dark",
                            style={"paddingLeft": "25%", "paddingRight": "25%"},
                            children=[
                                dbc.CardBody(
                                    dbc.Table(
                                        table_header + table_body,
                                        bordered=True,
                                        dark=True,
                                        striped=True,
                                        hover=True,
                                    )
                                )]),
                        id="collapse",
                        is_open=False,
                    ),
                ]
            )
        ]
    )


def create_cpu_info():
    return html.Div(
        id="cpu-info-container",
        className="container mb-3 text-center",
        children=[
            html.P(f"Processor: {get_cpu_name()}"),
            html.Div(
                className="row justify-content-center",
                children=[
                    html.P(f"Physical cores: {psutil.cpu_count(logical=False)}", className="col-3"),
                    html.P(f"Total cores: {psutil.cpu_count(logical=True)}", className="col-3"),
                ]
            ),
            html.Hr(
                className="border-2 border-top mb-4",
                style={"marginLeft": "30%", "marginRight": "30%"},
            ),
        ]
    )


def create_cpu_card():
    cpufreq = psutil.cpu_freq()
    min_freq = round(cpufreq.min / 1000, 2)
    max_freq = round(cpufreq.max / 1000, 2)

    if min_freq == 0:
        min_freq = 0.8

    if max_freq == 0:
        max_freq = float(math.ceil(round(cpufreq.current / 1000, 2)))

    return html.Div(
        id="cpu-card",
        className="mt-4 card-body row align-items-center",
        children=[
            create_cpu_info(),
            create_cpu_freq(),
            create_cpu_perc(),
            html.Div(
                id="min&max-freq",
                className="row mb-2 justify-items-center",
                style={"paddingLeft": "100px"},
                children=[
                    html.P(f"Min Freq.: {min_freq}Ghz", className="col-3"),
                    html.P(f"Max Freq.: {max_freq}Ghz", className="col-3"),
                ]
            ),
            create_cores_perc(),
        ]
    )


# CALLBACKS
@app.callback(
    Output("collapse", "is_open"),
    [Input("collapse-button", "n_clicks")],
    [State("collapse", "is_open")])
def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(Output('cpu-freq', 'value'),
              Input('cpu-freq-interval', 'n_intervals'))
def update_cpu_freq(n):
    cpufreq = psutil.cpu_freq()
    current_freq = round(cpufreq.current / 1000, 2)
    return current_freq


@app.callback(Output('cpu-perc', 'value'),
              Input('cpu-perc-interval', 'n_intervals'))
def update_cpu_perc(n):
    cpu_perc = psutil.cpu_percent()
    return cpu_perc
