import subprocess

from sembo.content import app


def get_output_from_command(option):
    process = subprocess.Popen(
        f"hostname -{option}" + " | awk '{print $1}'",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True,
        universal_newlines=True)

    stdout, stderr = process.communicate()
    return stdout, stderr


def get_ip_addr():
    out, err = get_output_from_command("I")

    if err:
        out, err = get_output_from_command("i")
        return out.strip()
    else:
        return out.strip()


# Running the server
server = app.server
if __name__ == "__main__":
    from waitress import serve

    ip_addr = get_ip_addr()

    # Using Waitress to serve the application in order to avoid warning of production server:
    print(f"SeMBo is running at http://{ip_addr}:8050")
    serve(app.server, host=ip_addr, port=8050)

    # Original line to run the application on localhost:
    # app.run(debug=True, host=ip_addr, port=8050)
