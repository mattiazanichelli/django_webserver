# dashboard
A dashboard for monitoring resources and perform tasks on a remove server created with Cubus
