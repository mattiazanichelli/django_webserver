# Sembo
A dashboard for monitoring resources and perform tasks on a remote server created with Cubus
